#!/bin/bash
set -e
$(dirname "$0")/install.sh
